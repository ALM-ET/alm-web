# @alm/sdk

Shared contract between `alm-api`, `alm-web` and `alm-console`.

- `permissions.ts` — the module and permission catalogue, the eight access-matrix
  rows from the recorded system, and `hasPermission` resolution. The API seeds
  its `permission` table from here, so the three apps cannot disagree about a
  permission string.
- `types.ts` — tenant, user, branding, flags, audit, pagination, error envelope.
- `client.ts` — `AlmClient`: cookie-based auth, in-memory access token, single
  shared refresh for concurrent 401s.
- `errors.ts` — `ApiError`, carrying field-level messages for form binding.

Consumed as a `file:` dependency locally and as a checked-out sibling repo in
CI. **Build it before installing the dependents** — they resolve `dist/`.

```bash
npm install && npm run build
```
